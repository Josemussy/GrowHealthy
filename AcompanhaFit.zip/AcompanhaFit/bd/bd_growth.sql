SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE TABLE `profissional` (
  `ID_Profiss` int(11) NOT NULL,
  `Nome_Profiss` varchar(100) NOT NULL,
  `Description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `personal` (
  `ID_Personal` int(11) NOT NULL,
  `Nome` varchar(100) NOT NULL,
  `ID_Profiss` int(11) NOT NULL,
  `Dt_Nasc` date DEFAULT NULL,
) ENGINE=InnoDB DEFAULT CHARSET=latin1;